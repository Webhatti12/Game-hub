import React, { useState } from 'react';
import axios from 'axios';

const TournamentForm = () => {
  const [formData, setFormData] = useState({
    title: '',
    game: '',
    entryFee: '',
    prize: '',
    organizer: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/api/tournaments/create', formData);
      alert('Tournament created!');
      setFormData({ title: '', game: '', entryFee: '', prize: '', organizer: '' });
      console.log(res.data);
    } catch (err) {
      console.error(err);
      alert('Failed to create tournament');
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginTop: '2rem' }}>
      <h2>Create Tournament</h2>
      <input type="text" name="title" placeholder="Title" value={formData.title} onChange={handleChange} required />
      <input type="text" name="game" placeholder="Game" value={formData.game} onChange={handleChange} required />
      <input type="number" name="entryFee" placeholder="Entry Fee" value={formData.entryFee} onChange={handleChange} required />
      <input type="text" name="prize" placeholder="Prize" value={formData.prize} onChange={handleChange} required />
      <input type="text" name="organizer" placeholder="Organizer" value={formData.organizer} onChange={handleChange} required />
      <br /><br />
      <button type="submit">Create Tournament</button>
    </form>
  );
};

export default TournamentForm;
