import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TournamentList = () => {
  const [tournaments, setTournaments] = useState([]);
  const [playerName, setPlayerName] = useState('');

  // Fetch tournaments from backend
  const fetchTournaments = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/tournaments');
      setTournaments(res.data);
    } catch (err) {
      console.error('Failed to fetch tournaments:', err);
    }
  };

  useEffect(() => {
    fetchTournaments();
  }, []);

  // Join tournament handler
  const handleJoin = async (id) => {
    if (!playerName) {
      alert('Please enter your name first!');
      return;
    }

    try {
      await axios.post(`http://localhost:5000/api/tournaments/join/${id}`, {
        playerName,
      });
      alert('You joined the tournament!');
      fetchTournaments(); // Refresh the list
    } catch (err) {
      console.error(err);
      alert('Failed to join tournament');
    }
  };

  // Declare winner handler
  const handleDeclareWinner = async (id) => {
    try {
      const res = await axios.post(`http://localhost:5000/api/tournaments/declare-winner/${id}`);
      alert(`Winner declared: ${res.data.winner}`);
      fetchTournaments(); // Refresh the list
    } catch (err) {
      console.error(err);
      alert('Failed to declare winner');
    }
  };

  return (
    <div style={{ marginTop: '2rem' }}>
      <h2>Available Tournaments</h2>
      <input
        type="text"
        placeholder="Enter your name to join"
        value={playerName}
        onChange={(e) => setPlayerName(e.target.value)}
        style={{ padding: '0.5rem', marginBottom: '1rem' }}
      />
      <ul>
        {tournaments.map((tournament) => (
          <li key={tournament._id} style={{ marginBottom: '1.5rem' }}>
            <strong>{tournament.title}</strong> | Game: {tournament.game} | Prize: {tournament.prize} | Players: {tournament.players.length}

            <button
              onClick={() => handleJoin(tournament._id)}
              style={{ marginLeft: '1rem' }}
            >
              Join
            </button>

            {/* Declare Winner Button (only if winner not declared yet) */}
            {tournament.players.length > 0 && !tournament.winner && (
              <button
                onClick={() => handleDeclareWinner(tournament._id)}
                style={{ marginLeft: '1rem' }}
              >
                Declare Winner
              </button>
            )}

            {/* Show Winner */}
            {tournament.winner && (
              <div style={{ marginTop: '0.5rem' }}>
                🏆 <strong>Winner:</strong> {tournament.winner}
              </div>
            )}

            {/* Show Players */}
            {tournament.players.length > 0 && (
              <div style={{ marginTop: '0.5rem', paddingLeft: '1rem' }}>
                <strong>Joined Players:</strong>
                <ul>
                  {tournament.players.map((player, index) => (
                    <li key={index}>• {player}</li>
                  ))}
                </ul>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TournamentList;
