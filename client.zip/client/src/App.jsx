// src/App.jsx
import React from 'react';
import TournamentList from './components/TournamentList';
import TournamentForm from './components/TournamentForm';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>🎮 Game Hub</h1>
      <TournamentForm />
      <TournamentList />
    </div>
  );
}

export default App;
