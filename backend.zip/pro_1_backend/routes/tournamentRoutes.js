// routes/tournamentRoutes.js
const express = require("express");
const router = express.Router();

const {
  createTournament,
  getTournaments,
  joinTournament,
  declareWinner,
} = require("../controllers/tournamentController");

router.post("/create", createTournament);
router.get("/", getTournaments);
router.post("/join/:id", joinTournament); // player joins a tournament
router.post("/declare-winner/:id", declareWinner); // ✅ Winner declared

module.exports = router;
