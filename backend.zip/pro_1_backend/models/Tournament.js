// models/Tournament.js
const mongoose = require("mongoose");

const tournamentSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  game: {
    type: String,
    required: true,
  },
  entryFee: {
    type: Number,
    required: true,
  },
  prize: {
    type: String,
    required: true,
  },
  players: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "Player",
  }],
  organizer: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    default: Date.now,
  },
  players: {
  type: [String], // List of player names or IDs
  default: [],
},
winner: {
    type: String,
    default: ''
  },
});

module.exports = mongoose.model("Tournament", tournamentSchema);
