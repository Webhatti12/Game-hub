// controllers/playerController.js
const Player = require("../models/Player");

const createPlayer = async (req, res) => {
  try {
    const player = new Player(req.body);
    const saved = await player.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  createPlayer,
};
