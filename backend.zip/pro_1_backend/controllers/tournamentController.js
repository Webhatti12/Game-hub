const Tournament = require('../models/Tournament');
// Create Tournament
const createTournament = async (req, res) => {
  try {
    const { title, game, entryFee, prize, organizer } = req.body;
    const newTournament = new Tournament({ title, game, entryFee, prize, organizer });
    await newTournament.save();
    res.status(201).json(newTournament);
  } catch (error) {
    res.status(500).json({ message: 'Failed to create tournament' });
  }
};

// Get All Tournaments
const getTournaments = async (req, res) => {
  try {
    const tournaments = await Tournament.find();
    res.json(tournaments);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch tournaments' });
  }
};

// Join Tournament (✨ NEW FEATURE)
const joinTournament = async (req, res) => {
  const { id } = req.params;
  const { playerName } = req.body;

  try {
    const tournament = await Tournament.findById(id);
    if (!tournament) {
      return res.status(404).json({ message: 'Tournament not found' });
    }

    tournament.players.push(playerName);
    await tournament.save();

    res.status(200).json({ message: 'Player joined successfully', tournament });
  } catch (error) {
    res.status(500).json({ message: 'Failed to join tournament' });
  }
};
const declareWinner = async (req, res) => {
    const { id } = req.params;
  
    try {
      const tournament = await Tournament.findById(id);
      if (!tournament || tournament.players.length === 0) {
        return res.status(400).json({ message: 'No players to declare a winner' });
      }
  
      const randomIndex = Math.floor(Math.random() * tournament.players.length);
      const winner = tournament.players[randomIndex];
      tournament.winner = winner;
      await tournament.save();
  
      res.status(200).json({ message: 'Winner declared', winner });
    } catch (error) {
      console.error('Error declaring winner:', error);
      res.status(500).json({ message: 'Failed to declare winner' });
    }
  };
  

module.exports = {
  createTournament,
  getTournaments,
  joinTournament,
  declareWinner,
};
